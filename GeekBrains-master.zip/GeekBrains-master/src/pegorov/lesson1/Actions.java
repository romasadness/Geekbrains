package pegorov.lesson1;

public interface Actions {
    void run();

    void jump();

    int getRunDistance();

    int getJumpHeight();
}
