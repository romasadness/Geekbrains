package pegorov.lesson4.chat;

public class lesson4 {
    public static void main(String[] args) {
        UMG umg = new UMG();
        umg.initField();
    }
}