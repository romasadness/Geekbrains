package pegorov.lesson4.game;

public class Main {
    public static void main(String[] args){
        Game gameInstance = new Game();
        gameInstance.initGame();
    }
}
