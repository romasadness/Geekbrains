package HomeWORK.Part2.lesson1.Task2;


public class Wall extends  Barrier {
    public Wall(int height){
        setHeight(height);
        setLength(0);
    }




}



