package HomeWORK.Part2.lesson1.Task2;

public class Runtrack extends  Barrier {
    public Runtrack (int length){
        setHeight(0);
        setLength(length);
    }
}
