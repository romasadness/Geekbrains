package HomeWORK.Part2.lesson1.Task2;

public class Barrier {
    private int height, length;
     public Barrier(){

    }
    public  void setHeight(int height){
        this.height = height;
    }
    public void setLength( int length){
        this.length = length;
    }
    public int getHeight(){
        return  height;
    }
    public  int getLength(){
        return  length;
    }

}
