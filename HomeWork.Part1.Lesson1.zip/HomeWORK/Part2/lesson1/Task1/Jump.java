package HomeWORK.Part2.lesson1.Task1;

public interface Jump {
    default void Jum(){

    }
}
