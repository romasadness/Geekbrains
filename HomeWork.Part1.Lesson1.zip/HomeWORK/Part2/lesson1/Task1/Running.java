package HomeWORK.Part2.lesson1.Task1;

public interface Running  {
     default void Run(){
    }

    }

