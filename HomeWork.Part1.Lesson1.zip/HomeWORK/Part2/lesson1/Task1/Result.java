package HomeWORK.Part2.lesson1.Task1;

public class Result  {
    public static void main(String[] args) {
        Cat cat1 = new Cat("Cat");
        cat1.Jum();
        cat1.Run();
        Robot rob1 = new Robot("Robot");
        rob1.Jum();
        rob1.Run();
        Human hum1 = new Human("Human");
        hum1.Jum();
        hum1.Run();
    }
}
